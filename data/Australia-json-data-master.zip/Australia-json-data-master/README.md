Australia-json-data
===================

geojson and topojson data for Australia

Basic repository for storing geojson and topojson of Australian data, converted from various sources for use in map projects.

This list - hopefully - will grow over time.
